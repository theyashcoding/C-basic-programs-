/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct demo
{
    char a;
    char b;
};

int main()
{
    struct demo obj;
    obj.a = 'A';
    printf("%ld" , sizeof(obj));
    printf("%c" , obj.a);
    return 0;


}
