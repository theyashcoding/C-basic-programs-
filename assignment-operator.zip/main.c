/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int x,y,z,t;
   x=5 , y=6 , z=x+(y*2) , t=x;
   
   printf("\n x%d , y=%d , z=%d , t=%d" , x,y,z,t);
   
   x,y,z=10;
   x=y=z=10;
   
   x=x+5;
   x +=5;
   
   y*=5;
   z/=2;
   x%=5;
   
   printf("\n x:%d y=%d z=%d t=%d" ,x,y,z,t);
   
   return 0;
}

