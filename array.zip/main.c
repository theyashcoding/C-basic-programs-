/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[5] =  {5 , 1 , 15 , 20 , 25};
    
    int i,j,m;
    
    i = ++a[1];
    j = a[1]++;
    m = a[i++];
    printf("%d,%d,%d", i,j,m );

    return 0;
}
